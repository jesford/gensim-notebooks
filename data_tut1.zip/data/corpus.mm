%%MatrixMarket matrix coordinate real general
2 2 1                                             
1 2 0.5
